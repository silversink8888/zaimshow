<div class="image_temp" data-position="center">
	<table class="table1">
		<tr>
			<td><a href="/money">ZAIMSHOW</a></td>
			<td><a href="/money/create">家計簿を入力</a></td>
			<td>履歴</td>
			<td>分析</td>
		</tr>
	</table>
</div>