<!DOCTYPE HTML>
<html>
<head>
<!--/ googleanalytics -->
@include('/money/header/googleanalytics')
<!-- googleanalytics /-->

<title>ZAIMSHOW</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="/assets/css/main.css" />
<link rel="stylesheet" href="/assets/css/main2.css" />


<script type="text/javascript" src="/assets/js/main2.js"></script>

<script type="text/javascript">
    function category_pulldown(){
        alert('category_pulldown');
    }
</script>
</head>