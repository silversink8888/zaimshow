@extends('money/layout')
@section('header')

@include('money/form', ['target' => 'store'])
@endsection