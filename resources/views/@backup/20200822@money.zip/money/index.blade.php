<!--/ ヘッダー -->
@include('/money/header')
<!-- ヘッダー /-->

<body class="is-preload">

<!--/ サイドバー -->
@include('/money/sidebar')
<!-- サイドバー /-->

<!-- wrapper -->
<div id="wrapper">

	<!-- main -->
	<div id="main">

		<!-- one -->
		<!--
		<section id="one">
		 -->
			<!--/ ヘッダーナビ -->
			@include('/money/headernavi')
			<!-- ヘッダーナビ /-->

			<div class="container">

				<div class="">
					<table>
						<tr>
							<td>記録数</td>
							<td>記録日数</td>
							<td>記録数</td>
						</tr>
					</table>
				</div>

				<div class="">
					<table>
						<tr>
							<td><p><?php echo DATE('n')?> 月の状況</p></td>
							<td></td>
							<td></td>
						</tr>

						<tr>
							<td>今月</td>
							<td>{{ $money_month_sum }}　円</td>
							<td></td>
						</tr>

						<tr>
							<td>今週</td>
							<td>{{ $money_week_sum }}　円</td>
							<td></td>
						</tr>

						<tr>
							<td>今日</td>
							<td>{{ $money_today_sum }}　円</td>
							<td></td>
						</tr>

					</table>
				</div>


				<!--/ 会計情報 -->
				@include('/money/info')
				<!-- 会計情報 /-->

			</div><!-- container -->
<!--
		</section>
 -->

		<!--/ フッター -->
		@include('money/footer')
		<!-- フッター /-->

	</div><!-- Main -->
</div><!-- Wrapper -->


</body>
</html>
