<table class="table-info">
	<tr>
		<th>ID</th>
		<th>購入日</th>
		<th>アカウント名</th>
		<th>商品名</th>
		<!--
		<th>大カテゴリー</th>
		<th>中カテゴリー</th>
		 -->       
		<th>価格</th>
		<th>メモ</th>
	</tr>

@foreach($money_arr as $money)
	<tr>
		<td>
		  <a href="/money/{{ $money->id }}/edit">{{ $money->id }}</a>
		</td>
		<td>{{ $money->buy_date }}</td>
		<td>{{ $money->name }}</td>
		<td>{{ $money->item_name }}</td>

		<!--
		<td>{{ $money->dai_category }}</td>
		<td>{{ $money->chuu_category  }}</td>
		-->

		<td>{{ $money->price }}</td>
		<td>{{ $money->memo }}</td>
		<td>
		  <form action="/money/{{ $money->id }}" method="post">
		    <input type="hidden" name="_method" value="DELETE">
		    <input type="hidden" name="_token" value="{{ csrf_token() }}">
		    <button type="submit" class="btn btn-xs btn-danger" aria-label="Left Align">
		    <span class="glyphicon glyphicon-trash"></span></button>
		  </form>
		</td>
	</tr>
@endforeach

</table>
