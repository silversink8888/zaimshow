<!--/ header -->
@extends('zaimshow/header')
@section('header')
@endsection<!-- header /-->
<!-- header /-->

<body class="is-preload">

<!--/ sidebar -->
@extends('zaimshow/sidebar')
@section('sidebar')
@endsection<!-- sidebar -->
<!-- sidebar /-->
	
	<!-- Wrapper -->
		<div id="wrapper">

			<!-- Main -->
				<div id="main">

					<!-- One -->
						<section id="one">
							<!--/ ヘッダー -->
							<div class="image_temp" data-position="center">
							<!--  
								<img src="images/banner.jpg" alt="" />
							-->
								<table class="table1">
								<tr>
									<td><a href="/zaimshow">ZAIMSHOW</a></td>
									<td><a href="/zaimshow/money">家計簿を入力</a></td>
									<td>履歴</td>
									<td>分析</td>
								</tr>
								</table>
							</div>
							<!-- ヘッダー /-->
							
							<div class="container">
								<header class="major">
									<h2>トップページ</h2>

								    <table class="table text-center">
								      <tr>
								        <th class="text-center">ID</th>
								        <th class="text-center">アカウント名</th>
								        <th class="text-center">商品名</th>
								        <th class="text-center">大カテゴリー</th>
								        <th class="text-center">中カテゴリー</th>
								        <th class="text-center">価格</th>
								        <th class="text-center">購入日</th>
								        <th class="text-center">メモ</th>
								        <th class="text-center">削除</th>
								      </tr>



								      @foreach($money_arr as $money)
								      <tr>
								        <td>
								          <a href="/book/{{ $money->id }}/edit">{{ $money->id }}</a>
								        </td>
								        <td>{{ $money->name }}</td>
								        <td>{{ $money->item_name }}</td>
								        <td>{{ $money->dai_category }}</td>
								        <td>{{ $money->chuu_category  }}</td>
								        <td>{{ $money->price }}</td>
								        <td>{{ $money->buy_date }}</td>
								        <td>{{ $money->memo }}</td>
								        <td>
								          <form action="/book/{{ $money->id }}" method="post">
								            <input type="hidden" name="_method" value="DELETE">
								            <input type="hidden" name="_token" value="{{ csrf_token() }}">
								            <button type="submit" class="btn btn-xs btn-danger" aria-label="Left Align"><span class="glyphicon glyphicon-trash"></span></button>
								          </form>
								        </td>
								      </tr>
								      @endforeach
								    </table>
    
								</header>
								<p></p>
							</div>
						</section>



				</div>
	
<!--/ footer -->
	@extends('zaimshow/footer')
	@section('footer')
	@endsection<!-- footer -->
<!-- footer /-->

</div><!-- Wrapper /-->





</body>
</html>