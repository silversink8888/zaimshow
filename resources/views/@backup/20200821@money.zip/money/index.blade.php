<!--/ ヘッダー -->
@include('/money/header')
<!-- ヘッダー /-->

<body class="is-preload">

<!--/ サイドバー -->
@include('/money/sidebar')
<!-- サイドバー /-->

<!-- wrapper -->
<div id="wrapper">

	<!-- main -->
	<div id="main">

		<!-- one -->
		<section id="one">
			<!--/ ヘッダーナビ -->
			@include('/money/headernavi')
			<!-- ヘッダーナビ /-->

			<div class="container">
				<header class="major">
				<h3>トップページ</h3>


				<!--/ 会計情報 -->
				@include('/money/info')
				<!-- 会計情報 /-->
				</header>
			</div><!-- container -->
		</section>

		<!--/ フッター -->
		@include('money/footer')
		<!-- フッター /-->

	</div><!-- Main -->
</div><!-- Wrapper -->


</body>
</html>
