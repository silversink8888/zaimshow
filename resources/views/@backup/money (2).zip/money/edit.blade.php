@extends('money/layout')
@section('header')

@include('money/form', ['target' => 'update'])
@endsection