<div class="col-md-6">
@if($target == 'store')
    <h2>家計簿　入力</h2>
@elseif($target == 'updaate')
    <h2>家計簿　編集</h2>
@endif
</div>

<div class="col-md-8 col-md-offset-1">
@include('money/message')
    @if($target == 'store')
	<form action="/money" method="post">
    @elseif($target == 'update')
	<form action="/money/{{ $money_arr->id }}" method="post">
	<input type="hidden" name="_method" value="PUT">
    @endif
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        
        
 	       <table class="table3">
		       <tr>
			       <td>購入日</td>
			       <td>品目名</td>
			       <td>カテゴリ</td>
			       <td>金額</td>
			       <td>メモ</td>
		       </tr>
		       
		       <tr>
			       <td><input type="text" class="form-control" name="item_name" value="{{ $money_arr->item_name }}"></td>
			       <td><input type="text" class="form-control" name="buy_date" value="{{ $money_arr->buy_date }}"></td>
			       <td><input type="text" class="form-control" name="dai_category " value="{{ $money_arr->dai_category  }}"></td>
			       <td><input type="text" class="form-control" name="price" value="{{ $money_arr->price }}"></td>
			       <td><input type="text" class="form-control" name="memo" value="{{ $money_arr->memo }}"></td>
		       </tr>
		       
		       <tr>
			       <td colspan="4"></td>
		       </tr>
		       
		       <tr>
			       <td colspan="4"><input type="image" src="{{ asset('img/input.png')}}" alt="入力する"></td>
		       </tr>
		       
	       </table>
        
        
        <button type="submit" class="btn btn-default">登録</button>
        <a href="/money">戻る</a>
    </form>
</div>
