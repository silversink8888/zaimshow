@include('/money/header')

<body class="is-preload">

<!--/ サイドバー -->
@include('/money/sidebar')
<!-- サイドバー /-->

<!-- wrapper -->
<div id="wrapper">

	<!-- main -->
	<div id="main">

		<!-- one -->
		<section id="one">
			<!--/ ヘッダーナビ -->
			@include('/money/headernavi')
			<!-- ヘッダーナビ /-->

			<div class="container">
				<header class="major">
				<h2>トップページ</h2>
				<p>qqqqqqqqqqqqqqqqq</p>
				</header>
			</div><!-- container -->
		</section>

		<!--/ フッター -->
		@include('money/footer')
		<!-- フッター /-->

	</div><!-- Main -->
</div><!-- Wrapper -->


</body>
</html>
