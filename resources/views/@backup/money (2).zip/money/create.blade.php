@include('/money/header')

<body class="is-preload">

<!--/ サイドバー -->
@include('/money/sidebar')
<!-- サイドバー /-->

<!-- wrapper -->
<div id="wrapper">

		<!-- one -->
		<section id="one">
			<!--/ ヘッダーナビ -->
			@include('/money/headernavi')
			<!-- ヘッダーナビ /-->
			
			<div>
				<table class="table2">
				       <tr>
					       <td>支出</td>
					       <td>収入</td>
					       <td>振替</td>
				       </tr>
			       </table>
		       </div>

			<div class="container">
				<header class="major">
				<div>
					@include('money/form', ['target' => 'store'])
				</div>
				</header>
			</div><!-- container -->
		</section>

		<!--/ フッター -->
		@include('/money/footer')
		<!-- フッター /-->


</div><!-- wrapper -->


</body>
</html>
