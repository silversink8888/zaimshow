<!DOCTYPE HTML>
<html>
<head>
<!--/ googleanalytics -->
{{-- 
@extends('zaimshow/header/googleanalytics')
@section('googleanalytics')
@endsection<!-- googleanalytics -->
 --}}

<!-- googleanalytics /-->
<title>ZAIMSHOW</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<link rel="stylesheet" href="assets/css/main2.css" />
</head>
@yield('header')