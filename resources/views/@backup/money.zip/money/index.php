<!--/ header -->
<?php 
	include(dirname(__FILE__). '/header.php'); 
?>
<!-- header /-->

<body class="is-preload">

	<!--/ sidebar -->
	<?php 
		include(dirname(__FILE__). '/sidebar.php'); 
	?>
	<!-- sidebar /-->
	
	<!-- Wrapper -->
		<div id="wrapper">

			<!-- Main -->
				<div id="main">

					<!-- One -->
						<section id="one">
							<!--/ ヘッダー -->
							<div class="image_temp" data-position="center">
							<!--  
								<img src="images/banner.jpg" alt="" />
							-->
								<table class="table1">
								<tr>
									<td><a href="index.php">ZAIMSHOW</a></td>
									<td><a href="money/index.php">家計簿を入力</a></td>
									<td>履歴</td>
									<td>分析</td>
								</tr>
								</table>
							</div>
							<!-- ヘッダー /-->
							
							<div class="container">
								<header class="major">
									<h2>トップページ</h2>
									<p>qqqqqqqqqqqqqqqqq
									</p>
								</header>
								<p></p>
							</div>
						</section>

					<!-- Two -->
						<section id="two">
							<div class="container">
								<h3>aaaaaaaaaaa</h3>
								<ul class="feature-icons">
									<li class="icon solid fa-code">Write all the code</li>
									<li class="icon solid fa-cubes">Stack small boxes</li>
									<li class="icon solid fa-book">Read books and stuff</li>
									<li class="icon solid fa-coffee">Drink much coffee</li>
									<li class="icon solid fa-bolt">Lightning bolt</li>
									<li class="icon solid fa-users">Shadow clone technique</li>
								</ul>
							</div>
						</section>

				</div>
	
<!--/ footer -->
<?php 
include(dirname(__FILE__). '/footer.php'); 
?>
<!-- footer /-->

</body>
</html>